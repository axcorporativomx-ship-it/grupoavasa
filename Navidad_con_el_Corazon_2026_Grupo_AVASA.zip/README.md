# Navidad con el Corazón 2026 — sección para Grupo AVASA

Este paquete está preparado para integrarse como una carpeta dentro del repositorio existente `axcorporativomx-ship-it/grupoavasa`, sin reemplazar archivos de la raíz.

## Integración
1. Descarga y descomprime este ZIP.
2. En el repositorio, crea una carpeta `navidadconelcorazon2026`.
3. Sube dentro de ella todos los archivos y la carpeta `assets`.
4. Si el sitio ya tiene navegación principal, agrega un enlace a `navidadconelcorazon2026/index.html`.

Si GitHub Pages está habilitado para el repositorio, la ruta dependerá de la configuración y del dominio publicado; no se asume que ya esté activa.

## Contenido
- `index.html`: portada de campaña.
- `voluntarios.html`: maqueta de formulario, deshabilitada hasta contar con backend y aviso de privacidad definitivo.
- `solicitar-apoyo.html`: maqueta de solicitud, deshabilitada hasta definir criterios y recepción segura.
- `cda.html`: espacio para mapa; no contiene ubicaciones inventadas.
- `terminos.html`, `privacidad.html`, `menores.html`, `autorizacion.html`, `arco.html`: borradores informativos.
- `assets/`: logotipos proporcionados por la organización.

## Antes de publicar
- Revisar y completar datos legales y avisos con asesoría jurídica.
- Definir responsable, domicilio, contacto de privacidad, finalidades, retención y controles de acceso.
- No habilitar formularios hasta configurar almacenamiento/recepción segura.
- Obtener y documentar las autorizaciones necesarias para participación e imágenes de menores.
- Agregar las direcciones confirmadas de los Centros de Acopio.
- Revisar los calendarios y criterios operativos antes de presentarlos como definitivos.
